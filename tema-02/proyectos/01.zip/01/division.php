<?php
/**
 * controlador division.php
 */

//cargo modelo
include "models/modelDividir.php";
//cargo vista
include "views/viewResultado.php";