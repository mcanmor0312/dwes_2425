<?php
/**
 * controlador sumar.php
 */

//cargo modelo
include "models/modelSumar.php";
//cargo vista
include "views/viewResultado.php";