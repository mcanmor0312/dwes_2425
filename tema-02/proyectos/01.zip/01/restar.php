<?php
/**
 * controlador restar.php
 */

//cargo modelo
include "models/modelRestar.php";
//cargo vista
include "views/viewResultado.php";