<?php
/**
 * controlador multiplicar.php
 */

//cargo modelo
include "models/modelMultiplicar.php";
//cargo vista
include "views/viewResultado.php";