<?php
/**
 * controlador sumar.php
 */

//cargo modelo
include "models/modelCalcular.php";
//cargo vista
include "views/viewResultado.php";