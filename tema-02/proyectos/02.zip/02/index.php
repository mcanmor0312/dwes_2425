<?php

/**
 * Calculadora primer proyecto
 */

 //Asignar modelo a las variables
//Modelo
//include "modelIndex.php";

//Vista - Muestra los valores
include "views/viewIndex.php";


