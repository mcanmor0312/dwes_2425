<?php
var_dump( empty($var) );
echo"<BR>";
$var1;
var_dump( empty($var1) );
echo"<BR>";
$var2 = "";
var_dump( empty($var2) );
echo"<BR>";
$var3 = true;
var_dump( empty($var3) );
echo"<BR>";
$var4 = 3;
var_dump( empty($var4) );
echo"<BR>";
$var5 = "2";
var_dump( empty($var5) );