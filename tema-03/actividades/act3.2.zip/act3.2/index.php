<?php

/**
 * controlador principal
 * 
 * ca
 */
//Modelo
include "models/model.index.php";

//Vista - Muestra los valores
include "views/view.index.php";
