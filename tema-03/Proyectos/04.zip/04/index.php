<?php

/**
 * controlador principal
 * 
 * ca
 */
include "libs/funciones.php";

 # Model
 include "models/model.index.php";

 # Vista
 include "views/view.index.php";