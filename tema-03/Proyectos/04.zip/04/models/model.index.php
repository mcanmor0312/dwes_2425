<?php



$libros=get_tabla_libros();

    