<?php

/**
 * controlador principal
 * 
 * ca
 */
//Cargar liberia
include "libs/funciones.php";

//Modelo
include "models/model.index.php";

//Vista - Muestra los valores
include "views/view.index.php";
