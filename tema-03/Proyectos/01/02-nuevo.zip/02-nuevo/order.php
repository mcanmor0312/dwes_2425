<?php

/**
 * controlador:create.php
 * descripcion: permitir añadir nuevo alumno a la tabla
 */
//Cargar liberia
include "libs/funciones.php";

 # Model
 include"models/model.order.php";

 # Vista
 include"views/view.index.php";