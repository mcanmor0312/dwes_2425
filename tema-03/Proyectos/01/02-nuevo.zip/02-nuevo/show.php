<?php

/**
 * controlador:create.php
 * descripcion: permitir añadir nuevo alumno a la tabla
 */
//Cargar liberia
include "libs/funciones.php";

 # Model
 include"models/model.show.php";

 # Vista
 include"views/view.show.php";