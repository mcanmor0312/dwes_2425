<?php

/**
 * ELiminar un elemento de la tabla
 */

 //Cargar liberia
include "libs/funciones.php";

//Modelo
include "models/model.edit.php";

//Vista - Muestra los valores
include "views/view.edit.php";
