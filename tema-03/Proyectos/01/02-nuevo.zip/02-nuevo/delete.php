<?php

/**
 * ELiminar un elemento de la tabla
 */

 //Cargar liberia
include "libs/funciones.php";

//Modelo
include "models/model.delete.php";

//Vista - Muestra los valores
include "views/view.index.php";
