<?php

    /*
        Ejemplo 13.

        Array o Matrices

        Matriz bidimensional con:

            - índice primario: escalar
            - índice secundario: asociativo
    */

    // Usando corchetes
    $alumnos=get_tabla_alumnos();
            

    // muestra un valor de la matriz        
    //echo $alumno[2] ['nombre']; 
    //echo '<BR>';

   /* foreach ($alumno as $i => $array) {
        foreach ($array as $j => $valor) {
            echo 'matriz['.$i.']['.$j.'] = '.$valor;
            echo '<BR>';
        }
    }
        */

