<?php

/**
 * M.C.U
 */

 //Asignar modelo a las variables
//Modelo
//include "models/modelIndex.php";

//Vista - Muestra los valores
include "views/viewIndex.php";


