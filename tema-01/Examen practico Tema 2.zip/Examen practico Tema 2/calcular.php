<?php

/**
 * M.C.U
 */

 //Asignar modelo a las variables
//Modelo
include "models/modelCalcular.php";

//Vista - Muestra los valores
include "views/viewCalculo.php";


